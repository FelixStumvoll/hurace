﻿using System.Threading.Tasks;
using Hurace.Core.Logic;
using Hurace.Core.Simulation;
using NUnit.Framework;

namespace Hurace.Core.Test
{
    public class RaceClockProviderTest
    {
        [Test]
        public async Task GetRaceClockTest()
        {
            var clock = await RaceClockProvider.Instance.GetRaceClock();
            Assert.That(() => clock is MockRaceClock);
        }
    }
}