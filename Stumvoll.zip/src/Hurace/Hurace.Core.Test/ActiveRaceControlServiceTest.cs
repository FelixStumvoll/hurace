﻿using System.Threading.Tasks;
using Hurace.Core.Logic.ActiveRaceControlService.Service;
using NUnit.Framework;

namespace Hurace.Core.Test
{
    public class ActiveRaceControlServiceTest
    {
        [Test]
        public async Task InitializeTest()
        {
            
        }
    }
}