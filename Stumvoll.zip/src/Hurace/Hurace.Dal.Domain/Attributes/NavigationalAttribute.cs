using System;

namespace Hurace.Dal.Domain.Attributes
{
    public class NavigationalAttribute : Attribute
    {
        
    }
}