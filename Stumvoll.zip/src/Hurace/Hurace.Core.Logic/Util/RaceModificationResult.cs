namespace Hurace.Core.Logic.Util
{
    public enum RaceModificationResult
    {
        Ok, Err, StartListDefined
    }
}