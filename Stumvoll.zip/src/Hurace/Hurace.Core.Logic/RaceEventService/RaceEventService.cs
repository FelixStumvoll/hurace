﻿namespace Hurace.Core.Logic.RaceEventService
{
    public class RaceEventService
    {
        
    }
}