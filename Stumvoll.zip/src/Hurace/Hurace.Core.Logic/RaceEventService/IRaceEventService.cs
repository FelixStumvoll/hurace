﻿using System.Threading.Tasks;
using Hurace.Dal.Domain;

namespace Hurace.Core.Logic.RaceEventService
{
    public interface IRaceEventService
    {
        
        
    }
}