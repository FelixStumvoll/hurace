﻿using Hurace.Core.Api;

namespace TestClient
{
    class Program
    {
        static void Main()
        {
            var instance = ServiceProvider.Instance;
        }
    }
}