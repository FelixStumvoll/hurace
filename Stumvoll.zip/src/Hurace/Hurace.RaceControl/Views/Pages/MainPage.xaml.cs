﻿namespace Hurace.RaceControl.Views.Pages
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}