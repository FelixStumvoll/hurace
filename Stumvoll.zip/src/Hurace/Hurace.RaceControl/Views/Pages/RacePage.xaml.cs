﻿namespace Hurace.RaceControl.Views.Pages
{
    public partial class RacePage
    {
        public RacePage()
        {
            InitializeComponent();
        }
    }
}