namespace Hurace.RaceControl.Views.Controls.RaceControlViews
{
    public partial class ActiveRaceControl
    {
        public ActiveRaceControl()
        {
            InitializeComponent();
        }
    }
}