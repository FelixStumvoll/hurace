namespace Hurace.RaceControl.Views.Controls.RaceControlViews
{
    public partial class RaceControlBaseView
    {
        public RaceControlBaseView()
        {
            InitializeComponent();
        }
    }
}