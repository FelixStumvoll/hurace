namespace Hurace.RaceControl.Views.Controls.RaceControlViews
{
    public partial class ReadonlyRaceControl
    {
        public ReadonlyRaceControl()
        {
            InitializeComponent();
        }
    }
}