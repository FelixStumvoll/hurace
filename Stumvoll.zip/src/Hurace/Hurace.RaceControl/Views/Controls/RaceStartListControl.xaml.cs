namespace Hurace.RaceControl.Views.Controls
{
    public partial class RaceStartListControl
    {
        public RaceStartListControl()
        {
            InitializeComponent();

        }
    }
}