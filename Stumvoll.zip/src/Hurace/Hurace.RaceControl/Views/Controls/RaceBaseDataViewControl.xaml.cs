﻿namespace Hurace.RaceControl.Views.Controls
{
    public partial class RaceBaseDataViewControl
    {
        public RaceBaseDataViewControl()
        {
            InitializeComponent();
        }
    }
}