namespace Hurace.RaceControl.Views.Controls.SubViews
{
    public partial class RankingView
    {
        public RankingView()
        {
            InitializeComponent();
        }
    }
}