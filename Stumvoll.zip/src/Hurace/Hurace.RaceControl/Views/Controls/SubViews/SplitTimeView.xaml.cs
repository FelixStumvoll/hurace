namespace Hurace.RaceControl.Views.Controls.SubViews
{
    public partial class SplitTimeView
    {
        public SplitTimeView()
        {
            InitializeComponent();
        }
    }
}