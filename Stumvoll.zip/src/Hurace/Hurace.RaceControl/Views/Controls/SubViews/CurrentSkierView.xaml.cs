namespace Hurace.RaceControl.Views.Controls.SubViews
{
    public partial class CurrentSkierView
    {
        public CurrentSkierView()
        {
            InitializeComponent();
        }
    }
}