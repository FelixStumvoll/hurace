﻿namespace Hurace.RaceControl.Views.Controls
{
    /// <summary>
    /// Interaction logic for RaceDisplayControl.xaml
    /// </summary>
    public partial class RaceDisplayControl
    {
        public RaceDisplayControl()
        {
            InitializeComponent();
        }
    }
}
