﻿namespace Hurace.RaceControl.Views.Controls
{
    public partial class RaceView
    {
        public RaceView()
        {
            InitializeComponent();
        }
    }
}