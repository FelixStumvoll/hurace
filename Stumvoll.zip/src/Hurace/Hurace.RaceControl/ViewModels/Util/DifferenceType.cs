namespace Hurace.RaceControl.ViewModels.Util
{
    public enum DifferenceType
    {
        Lower, Equal, Higher
    }
}