using System.Threading.Tasks;

namespace Hurace.RaceControl.ViewModels.RaceControlViewModels
{
    public interface IRaceControlViewModel
    {
        Task SetupAsync();
    }
}