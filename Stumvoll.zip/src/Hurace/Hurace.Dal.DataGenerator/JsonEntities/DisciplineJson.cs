﻿using System.Diagnostics.CodeAnalysis;

namespace Hurace.DataGenerator.JsonEntities
{
    [ExcludeFromCodeCoverage]
    public class DisciplineJson
    {
        public string Name { get; set; }
    }
}